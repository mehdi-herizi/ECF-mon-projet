// TODO fetch() pour recupéré les données du json

const url = "http://127.0.0.1:5500/js/data/jeux.jsonxxx"

 const gameList = document.querySelector(".game-list");

// Méthode 1

fetch(url)
    .then((response) => {
        console.log(response);
        return response.json();
    })
    .then((data) => {
        console.log(data)
        console.log(data[0].name);

        // Parcourir le tableau et créer un élément pour chaque mois
        for (let i = 0; i < data.length; i++) {
            // Créer les éléments
            const article = document.createElement("article")
            article.classList = "game"
            article.style.backgroundColor= "#F5F5F5";
            article.innerHTML = `
            <img src="${data[i].imageUrl}" alt="${data[i].name}" >
            <h2>${data[i].name}</h2>
            <p>${data[i].description}</p>
            `
            gameList.appendChild(article)
        }
        console.log("THEN2")


    })
    .catch((e) => console.warn("Erreur réseau :" + e))


console.log("END")






// Méthode 2

// Fonction async



