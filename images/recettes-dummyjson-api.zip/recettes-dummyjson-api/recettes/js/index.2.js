// TODO fetch() pour recupéré les données du json

console.log("FETCH DATA");

const recipesUrl = "https://dummyjson.com/recipes"

const info = document.querySelector(".info");

// Méthode 2

async function fetchData(url) {
    try {
        info.textContent = "Veuillez patienter"
        const response = await fetch(url) // Equivalent du premier then
        info.textContent = "";
        const data = await response.json() // 2eme then renvoie [...] Données brutes
        console.log("data __________ ", data.recipes);

        return data.recipes;
    } catch (e) {
        console.error("Erreur d'url", e);

    }
}


// TODO Fonction intermediaire qui filtre



async function displayGames() {
    try {
        const gameList = document.querySelector(".recipes-list"); // Conteneur coté client

        const data = await fetchData(recipesUrl);

        for (let i = 0; i < data.length; i++) {
            // Créer les éléments
            const article = document.createElement("article")

            article.classList = "recipe"

            article.style.backgroundColor = "#F5F5F5";

            article.innerHTML = `
            <img src="${data[i].image}" alt="${data[i].name}" >
            <h2>${data[i].name}</h2>
            `
            gameList.appendChild(article) // Affichage - insertion des éléments HTML
        }
    } catch (error) {
        console.error("Probleme d'affichage", error);

    }
}


displayGames();

// TODO La méthode filter

// const userSearch = "med"

// const dificulty = [ {diff:"easy"}, {diff:"medium"},{diff:"easy"}, {diff:"medium"}, {diff:"hard"} ];

// console.log(dificulty.filter( (arrayElmt) => arrayElmt.diff === "medium"   ) ); // out: medium

// console.log( "------> " +  "Salut tout le monde !".includes('') );


console.log("END")









