// TODO fetch() pour recupéré les données du json



console.log("FETCH DATA");



const userUrl = "http://127.0.0.1:5500/js/data/users.json"
const gamesUrl = "http://127.0.0.1:5500/js/data/jeux.json"

const info = document.querySelector(".info");

// Méthode 2

async function fetchData(url) {
    try {
        info.textContent = "Veuillez patienter"
        const response = await fetch(url) // Equivalent du premier then
        info.textContent = "";
        const data = await response.json() // 2eme then renvoie [...] Données brutes
        return data;
    } catch (e) {
        console.error("Erreur d'url", e);
        
    }
}

fetchData(userUrl);
fetchData(gamesUrl);

async function displayGames() {
    const gameList = document.querySelector(".game-list");
    const data = await fetchData(gamesUrl);
    for (let i = 0; i < data.length; i++) {
        // Créer les éléments
        const article = document.createElement("article")
        article.classList = "game"
        article.style.backgroundColor = "#F5F5F5";
        article.innerHTML = `
            <img src="${data[i].imageUrl}" alt="${data[i].name}" >
            <h2>${data[i].name}</h2>
            <p>${data[i].description}</p>
            `
        gameList.appendChild(article)
    }
}


displayGames();

// TODO Afficher les users 





console.log("END")









